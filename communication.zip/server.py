import socketserver
import sys


class MyTCPHandler(socketserver.BaseRequestHandler):
    def handle(self):
        sock = self.request
 
  
        
        rbuff = sock.recv(1024)    
        received = str(rbuff,encoding='utf-8')
        if received == 'q' or received == 'Q':
             sock.send(rbuff)
             sock.close()
            
        else:
             
             print('{0} \n'.format(received))
             


      



'''if len(sys.argv) < 2:
        print('{0} <Bind IP>'.format(sys.argv[0]))
        sys.exit()'''
bindIP = "169.254.69.1"
bindPort = 5425

server = socketserver.TCPServer((bindIP,bindPort),MyTCPHandler)

print('서버시작..')

server.serve_forever()
